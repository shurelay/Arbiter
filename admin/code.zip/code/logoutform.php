<?php
/**
 * Created by PhpStorm.
 * User: aidanmaddox
 * Date: 11/1/18
 * Time: 2:58 PM
 */
?>
<html>

<form action="logout.php" method="post">
Click to logout.
    <input type="submit" name="logout">

</form>

</html>
