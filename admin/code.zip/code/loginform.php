<?php
session_start();

?>

<html>

<form method="post">
    Please input your password bellow:
    <br/>
    <input type="text" name="password">
    <br/>
    <input type="submit">
    psst...The password is "password"
</form>
</html>
